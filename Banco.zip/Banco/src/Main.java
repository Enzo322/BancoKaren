import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		menuAcesso();
	}

	private static void menuAcesso() {
		System.out.print("\nInforme sua profiss�o:\n1 - Cliente\n2 - ADM\n3 - FInalizar sistema\n--> ");
		switch(sc.nextInt()){
			case 1:
				int tipo = tipo();
				if (tipo == 1 || tipo == 2) {
					Conta(tipo);
				} else {
					transacaoCredito();
				}
				break;
			case 2:
				menuADM();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Op��o inv�lida");
		}
	}
	private static void menuADM() {
		int opcao;
		do {
			System.out.print("\n|-----------Menu de a��es-----------|" + "\n|    O que voc� deseja realizar:    |"
					+ "\n|  1 - Adicionar                    |" + "\n|  2 - Sair                         |"
					+ "\n|-----------------------------------|" + "\n  |--> ");
			opcao = sc.nextInt();
		} while (opcao < 1 || opcao > 2);
		if (opcao == 1) {
			cadastroConta().adicionar();
			menuADM();
		} else {
			menuAcesso();
		}
	}
	private static int tipo() {
		System.out.print("Informe qual o tipo de sua conta: " + "\n1 - Corrente" + "\n2 - Poupan�a" + "\n3 - Cr�dito"
				+ "\n--> ");
		return sc.nextInt();
	}
	private static Conta cadastroConta() {
		String titular, senha, profissao;
		long cpf;
		int numero;
		double limite, rendimento;
		int tipo = tipo();
		System.out.print("Informe o titular da conta: ");
		titular = sc.next();
		System.out.print("Informe o seu cpf: ");
		cpf = sc.nextLong();
		System.out.print("Informe a sua profiss�o: ");
		profissao = sc.next();
		System.out.print("Informe a senha da conta: ");
		senha = sc.next();
		System.out.print("Informe o n�mero da conta: ");
		numero = sc.nextInt();
		switch (tipo) {
			case 1:
				System.out.print("Informe o limite da conta corrente: ");
				limite = sc.nextDouble();
				return new Corrente(senha, titular, numero, profissao, cpf, limite);
			case 2:
				System.out.print("Informe o rendimento da conta poupan�a: ");
				rendimento = sc.nextDouble();
				return new Poupanca(senha, titular, numero, profissao, cpf, rendimento);
			case 3:
				System.out.print("Informe o limite da conta de cr�dito: ");
				limite = sc.nextDouble();
				return new Credito(senha, titular, numero, profissao, cpf, limite);
			default:
				System.out.println("Op��o inv�lida!");
		}
		return null;
	}
  	private static void Conta(int tipo) {
		int opcao = 0;
			do {
				for (int i = 0; i < Conta.getListaContas().size(); i++) {
					if (Conta.getListaContas().get(i).verificaConta(numConta())) {
						int outraOperacao = 2;
						do {
							System.out.println("\nOl� " + Conta.getListaContas().get(i).getTitular() + "!" +
									"\nProfiss�o: " + Conta.getListaContas().get(i).getProfissao() +
									"\nCPF: "+ Conta.getListaContas().get(i).getCpf());
							if(tipo == 1) {
								opcao = menuCorrente(Conta.getListaContas().get(i));
								if (opcao != 6) {
									boolean autenticou = transacaoCorrente(opcao, Conta.getListaContas().get(i));
									if (autenticou) {
										System.out.print("\nDeseja realizar uma nova opera��o? " + "\n1 - Sim"
												+ "\n2 - N�o" + "\n--> ");
										outraOperacao = sc.nextInt();
									}
								}
							}else if(tipo == 2){
								opcao = menuPoupanca(Conta.getListaContas().get(i));
								if (opcao != 6) {
									boolean autenticou = transacaoPoupanca(opcao, Conta.getListaContas().get(i));
									if (autenticou) {
										System.out.print("\nDeseja realizar uma nova opera��o? " + "\n1 - Sim"
												+ "\n2 - N�o" + "\n--> ");
										outraOperacao = sc.nextInt();
									}
								}
							}else if(tipo == 3){
								transacaoCredito();
							}
						} while (outraOperacao == 1 && opcao != 6);
						System.out.println("Sess�o encerrada!");
						menuAcesso();
						break;
					}
				}
			} while (true);
	}
	private static int numConta() {
		System.out.print("Informe o n�mero da conta: ");
		return sc.nextInt();
	}

	private static void transacaoCredito() {
		for (int i = 0; i < Conta.getListaContas().size(); i++) {
			if (Conta.getListaContas().get(i).verificaConta(numConta())) {
				System.out.print("Insira o valor da fatura a ser paga: ");
				double fatura = sc.nextDouble();
				Credito credito = (Credito) Conta.getListaContas().get(i);
				credito.pagarFatura(fatura);
				System.out.println("Sess�o encerrada!");
				menuAcesso();
			}
		}
	}
	private static boolean transacaoCorrente(int opcao, Conta conta) {
		double valor = 0;
		Corrente contaCC = (Corrente) conta;
		if (autentica(contaCC)) {
				if (opcao == 2 || opcao == 3 || opcao == 4) {
					System.out.print("\nInsira o valor " + (opcao == 2 ? "do dep�sito: " : (opcao == 3 ? "do saque: " : "da transfer�ncia: ") + ": "));
					valor = sc.nextDouble();
				}
				switch(opcao) {
				case 1:
					System.out.println("Saldo: R$" + conta.getSaldo());
					break;
				case 2:
					contaCC.deposito(valor);
					break;
				case 3:
					contaCC.saque(valor);
					break;
				case 4:
					System.out.print("Informe o n�mero da conta para qual voc� deseja transferir: ");
					int num = sc.nextInt();
						conta.transferencia(valor, num);
					break;
				case 5:
					System.out.println("Sess�o encerrada!");
					menuAcesso();
				default:
					System.out.println("Op��o inv�lida!!");
				}
			return true;
		} else {
			return false;
		}
	}
	private static boolean transacaoPoupanca(int opcao, Conta conta) {
		double valor = 0;
		Poupanca contaP = (Poupanca) conta;
		if (autentica(conta)) {
				if (opcao == 2 || opcao == 3) {
					System.out.print("\nInsira o " + (opcao == 2 ? "valor do dep�sito: " : (opcao == 3 ? "valor do saque: " : (opcao == 4 ? "valor da transfer�ncia: " : "tanto de meses para render: ") + ": ")));
					valor = sc.nextDouble();
				}
				switch(opcao) {
				case 1:
					System.out.println("Saldo: R$" + contaP.getDinheiro());
					break;
				case 2:
					contaP.deposito(valor);
					break;
				case 3:
					contaP.saque(valor);
					break;
				case 4:
					System.out.print("Informe o n�mero da conta para qual voc� deseja transferir: ");
					int num = sc.nextInt();
						conta.transferencia(valor, num);
					break;
				case 5:
					System.out.print("Insira quantos meses ir� render: ");
					int meses = sc.nextInt();
					contaP.render(meses);
					break;
				default:
					System.out.println("Op��o inv�lida!!");
				}
			return true;
		} else {
			return false;
		}
	}

	private static int menuCorrente(Conta conta) {
		int opcao;
		do {
			System.out.print("\n|-----------Menu de a��es-----------|"
					+ "\n|    O que voc� deseja realizar:    |"
					+ "\n|  1 - Saldo                        |"
					+ "\n|  2 - Dep�sito                     |"
					+ "\n|  3 - Saque                        |"
					+ "\n|  4 - Transferir                   |"
					+ "\n|  5 - Sair                         |"
					+ "\n|-----------------------------------|"
					+ "\n  |--> ");
			opcao = sc.nextInt();
		} while (opcao < 1 || opcao > 5);
		return opcao;
	}
	private static int menuPoupanca(Conta conta) {
		int opcao;
		do {
			System.out.print("\n|-----------Menu de a��es-----------|" 
					+ "\n|    O que voc� deseja realizar:    |"
					+ "\n|  1 - Saldo                        |" 
					+ "\n|  2 - Dep�sito                     |"
					+ "\n|  3 - Saque                        |" 
					+ "\n|  4 - Transferir                   |"
					+ "\n|  5 - Render                       |" 
					+ "\n|  6 - Sair                         |"
					+ "\n|-----------------------------------|"
					+ "\n  |--> ");
			opcao = sc.nextInt();
		} while (opcao < 1 || opcao > 6);
		return opcao;
	}

	static boolean autentica(Conta cc) {
		for (int i = 0; i < 3; i++) {
			System.out.print("Tentativa " + (i + 1) + "/3\nSenha: ");
			if (cc.verificaSenha(sc.next())) {
				return true;
			}
		}
		return false;
	}
}

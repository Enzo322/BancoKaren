import java.util.ArrayList;

public class Credito extends Conta{
	
	private double limite;
	
	Credito(String senha, String titular, int numero, String profissao, long cpf,  double limite) {
		super(senha, titular, numero, profissao, cpf);
		this.limite = limite;
	}
	
	public void pagarFatura(double fatura) {
		double fatur = this.limite;
		if(limite > 0 && limite >= fatura) {
			fatur -= fatura;
			System.out.println("Saldo anterior: "+this.getSaldo()+"\nSaldo atual: "+fatur+"\nFatura paga!");
		}else {
			System.out.println("...");
		}
	}
}

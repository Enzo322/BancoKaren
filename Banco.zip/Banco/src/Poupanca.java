import java.util.ArrayList;

public class Poupanca extends Conta {
	
	private double rendimento, dinheiro;

	Poupanca(String senha, String titular, int numero, String profissao, long cpf, double rendimento) {
		super(senha, titular, numero, profissao, cpf);
		this.rendimento = rendimento;
	}
	void deposito(double valor) {
		if(valor > 0) {
		String msg = "Saldo anterior: R$"+ super.getSaldo();
		dinheiro += super.getSaldo() + valor;
		System.out.println(msg + "\nSaldo Atual: R$" + dinheiro);
		} else {
			System.out.println("Imposs�vel realizar um dep�sito com esse valor");
		}
	}
	void saque(double valor) {
		if(getSaldo() >= valor && getSaldo() > 0) {
		String msg = "Saldo anterior: R$"+ getSaldo();
		dinheiro = getSaldo() - valor;
		System.out.println(msg + "\nSaldo Atual: R$" + dinheiro);
		} else if(valor == 0){
			System.out.println("Imposs�vel realizar um saque com esse valor");
		} else {
			System.out.println("Saldo insuficiente!");
		}
	}
	public void render(int meses) {
		double renda = dinheiro * (meses * 0.05);
		System.out.println("Rendimento nesses "+meses+" meses: "+ renda);
		super.setSaldo(super.getSaldo() + renda) ;
	}

	public double getDinheiro() {
		return dinheiro;
	}

}

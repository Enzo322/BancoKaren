import java.util.ArrayList;

public class Corrente extends Conta{
	
	private double limite, dinheiro;

	Corrente(String senha, String titular, int numero, String profissao, long cpf, double limite) {
		super(senha, titular, numero, profissao, cpf);
		this.limite = limite;
	}

	void deposito(double valor) {
		if(valor > 0) {
		String msg = "Saldo anterior: R$"+ super.getSaldo();
		dinheiro += super.getSaldo() + valor;
		System.out.println(msg + "\nSaldo Atual: R$" + dinheiro);
		super.setSaldo(dinheiro);
		} else {
			System.out.println("Imposs�vel realizar um dep�sito com esse valor");
		}
	}
	void saque(double valor) {
		if(valor <= this.limite) {
		if(getSaldo() >= valor && getSaldo() > 0) {
		String msg = "Saldo anterior: R$"+ getSaldo();
		dinheiro = getSaldo() - valor;
		System.out.println(msg + "\nSaldo Atual: R$" + dinheiro);
		} else if(valor == 0){
			System.out.println("Imposs�vel realizar um saque com esse valor");
		} else {
			System.out.println("Saldo insuficiente!");
		}
		}else {
			System.out.println("Limite atingido!!");
		}
		setSaldo(getSaldo() - valor);
	}

	
}

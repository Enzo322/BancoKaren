import java.util.ArrayList;

public class Conta {
	
	static ArrayList<Conta> listaContas = new ArrayList<Conta>();
	
	private int numero;
	private String titular, senha, profissao;
	private long cpf;
	private double saldo;
	
	Conta(String senha, String titular, int numero, String profissao, long cpf){
		saldo = 0;
		this.titular = titular;
		this.senha = senha;
		this.numero = numero;
		this.profissao = profissao;
		this.cpf = cpf;
	}

	public String getProfissao() {
		return profissao;
	}

	public long getCpf() {
		return cpf;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getTitular() {
		return titular;
	}

	boolean verificaConta(int numero) {
		if(this.numero == numero) {
			return true;
		}
		return false;
	}
	boolean verificaSenha(String senha) {
		if(this.senha.equals(senha)) {
			return true;
		}
		return false;
	}
	void adicionar() {
		listaContas.add(this);
	}
	void transferencia(double valor, int num) {
		for(int i = 0; i < Conta.getListaContas().size();i++) {
			if(Conta.getListaContas().get(i).verificaConta(num)) {
				this.saldo -= valor;
				listaContas.get(i).saldo += valor;
			}else{
//				System.out.println("Conta nao encontrada!");
			}
		}
	}

	public static ArrayList<Conta> getListaContas() {
		return listaContas;
	}

}
